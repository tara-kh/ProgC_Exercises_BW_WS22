/* Aufgabe 4-2
   verschiedene Versionen der Funktion swapInteger  */

#include <stdlib.h>
#include <stdio.h>
#include "Diverses.h"


/* Deklaration der drei Versionen, siehe Uebungsblatt */
void swapInteger1(int, int);
void swapInteger2(int*, int*);
void swapInteger3(int**, int**);


int main(void)
{
  int x=5;
  int *px=&x;
  
  int y=6;
  int *py=&y;
  
  
  printf("\nWert x: %d   und   Wert y: %d\n", x, y);
  swapInteger1(x,y);
  printf("Wert x: %d   und   Wert y: %d\n", x, y);

  x=5;y=6;
  printf("\nWert x: %d   und   Wert y: %d\n", x, y);
  swapInteger2(px,py);
  printf("Wert x: %d   und   Wert y: %d\n", x, y);
  
  x=5;y=6;
  printf("\nWert x: %d   und   Wert y: %d\n", x, y);
  printf("Wert x: %d   und   Wert y: %d  (erhalten durch Dereferenzierung)\n",
         *px, *py);
  swapInteger3(&px,&py);
  printf("Wert x: %d   und   Wert y: %d\n", x, y);
  printf("Wert x: %d   und   Wert y: %d  (erhalten durch Dereferenzierung)\n",
         *px, *py);

  PAUSE
  return 0;
}

void swapInteger1(int a, int b)
{
/* Version 1:
   Geht nicht, da a und b lokale Variable der Funktion swapInteger1 sind.
*/
	int dummy=a;
	a=b;
	b=dummy;
	printf("swapInteger Version 1 ....\n");
	return;
}

void swapInteger2(int *a,int *b)
{
/* Version 2:
   Funktioniert, da die Zeiger a und b auf Speicherort zeigen,
   wo die Integerwerte zu finden sind.
*/

	int dummy=*a;
	*a=*b;
	*b=dummy;
	printf("swapInteger Version 2 ....\n");
	return;
}
	
void swapInteger3(int **a,int **b)
{
/* Version 3:
   Funktioniert auch, allerdings werden hier die  Zeiger pa und pb veraendert,
   der Speicherinhalt der Integerwerte bleibt  gleich
*/

	int *pdummy=*a;
	*a=*b;
	*b=pdummy;
	printf("swapInteger Version 3 ....\n");
	return;
}
	
