/* Aufgabe 4-6
   Numerische Integrationsverfahren */
 
#include <stdlib.h>
#include <stdio.h>
#include "Diverses.h"

double fkt(double x)
{
	double y;
	y=-0.25*x*x + 1.5 * x +1.75;
	return y ;
}

/* 
Rueckgabewert: Näherngswert des Integrals
a            : Untergrenze des Integrationsintervalls
b            : Obergrenze des  Integrationsintervalls
n            : Anzahl der Teilintervalle
f            : Funktion, die integriert werden soll 
*/
double fkt_integration(double a, double e, int n, double(*f)(double))
{
	
  double x, dx;
  double y1, y2;
  
  double erg=0.0;
  
  dx= (e-a)/n;
  for ( x=a; x < e + (dx/2.0); x=x+dx){
    y1=(*f)(x);
	y2=(*f)(x+dx);
	erg += dx * (y2+y1)/2.0; // siehe Trapezregel
  }	
  return erg;
}

int main(void)
{
  int r, anz;
  double anf, end, Y;
  do
  {
    printf("Gib untere Intergrationsgrenze ein: ");
    r=scanf("%lf",&anf); INCLR
  }
  while (r<1);
  do
  {
    printf("Gib obere Intgrationsgrenze ein:  ");
    r=scanf("%lf",&end); INCLR
  }
  while (r<1 || end<=anf);
  do
  {
    printf("Gib Anzahl der Teilintervalle an:   ");
    r=scanf("%d",&anz); INCLR
  }
  while (r<1 || anz <= 0 );

  Y=fkt_integration(anf, end, anz, fkt);
  
  printf("\nDer Naeherungswert des Integrals ist %f.\n\n",Y); 
  
}
