/* Aufgabe 4-4
   Funktion von zwei Variablen mit zwei Rueckgabewerten */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "Diverses.h"

int func(float, float, float*);

int main(void)
{
  float x1, x2, y;
  
  x1=5;
  x2=4;
  
  if (func(x1,x2,&y))
  {
	printf("Das Ergebnis ist %f\n",y);
  }
  else
  {
	printf("Das Ergebnis ist keine reelle Zahl\n");
  }
  PAUSE
  return 0;
  /* system("Pause"); */
}

/* Funktion mit zwei Rueckgabewerten:
   berechnet sqrt(x*x -y*y), sofern definiert
*/
int func(float x, float y, float *erg)
{
	float x_quad=x*x;
	float y_quad=y*y;
	
	if (x_quad >= y_quad)
    {
		*erg=sqrt(x_quad-y_quad);
		return 1;
	} 
	else
    {	
		*erg=0; 
		return 0;
	} 
}
