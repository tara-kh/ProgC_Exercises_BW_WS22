/* Aufgabe 4-5
   Berechnung einer Potenz mit natuerlichem Exponenten mittels
   (a) iterativer Funktion
   (b) rekursiver Funktion  */

#include <stdlib.h>
#include <stdio.h>
#include "Diverses.h"

/* Funktion zur iterativen Berechnung der Potenz a^n */
double potenz_iterativ (double a, int n)
{
  double erg=1.;
  int i;
  for(i=1; i<=n; i=i+1) { erg=erg*a; }
  return erg;
}

/* Funktion zur rekursiven Berechnung der Potenz a^n */
double potenz_rekursiv (double a, int n)
{
  if (n==0) { return 1.; }
  else { return a*potenz_rekursiv(a,n-1); }
}

/* Hauptprogramm */
int main(void)
{
  int r, expo;
  double basis;
  /* Eingabe */
  do
  {
    printf("\nGib beliebige Zahl als Basis ein: "); 
    r=scanf("%lf",&basis); INCLR
  }
  while (r<1);
  do
  {
    printf("\nGib nichtnegative ganze Zahl als Exponent ein: "); 
    r=scanf("%d",&expo); INCLR
  }
  while (r<1 || expo<0);
  /* Ausgabe */
  printf("\nPotenz iterativ = %lf\n", potenz_iterativ(basis,expo));
  printf("Potenz rekursiv = %lf\n", potenz_rekursiv(basis,expo));
  PAUSE
}

