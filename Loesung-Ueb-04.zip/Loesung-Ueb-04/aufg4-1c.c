/* Aufgabe 4-1c
   Funktion f�r sinus hyperbolicus */
 
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "Diverses.h"

void sinhyp (double x, double *y)
{
  *y = (exp(x)-exp(-x))/2;
}

int main(void)
{
  double a, b, h, x, y;
  int r, i=0;
  
  do
  {
    printf("Gib Tabellenanfang ein:       ");
    r=scanf("%lf",&a); INCLR
  }
  while (r<1);
  do
  {
    printf("Gib Tabellenende ein ( >= a): ");
    r=scanf("%lf",&b); INCLR
  }
  while (r<1 || b<a);
  do
  {
    printf("Gib Schrittweite ein ( > 0):  ");
    r=scanf("%lf",&h); INCLR
  }
  while (r<1 || h<=0);
  
  do
  {
    x = a+i*h;
    sinhyp (x, &y);
    printf("\n%f  %f",x,y);
    i = i+1;
  }
  while (x<b-h/2);
  
  printf("\n");
  PAUSE
}

