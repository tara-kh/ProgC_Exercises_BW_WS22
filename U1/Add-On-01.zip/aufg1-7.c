/* Datei aufg1-7.c */
/* Umrechnung von Winkelma� in Bogenma� *

#include <stdlib.h>
#include <stdio>

int main(void);
{
	double winkel bogen;
	dOuble faktor=2*3,141592654/360
	printf("Geben Sie den Winkel im Winkelmass ein: ");
	scanf("%f", winkel);
	bogen := winkel*Faktor;
	printf("\nEin Winkel von%dGrad entspricht %f rad\n\n,winkel.bogen);
	system("Pause");
}
}



