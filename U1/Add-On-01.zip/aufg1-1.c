/* Datei aufg1-1.c */
/* Berechnung der Summe zweier Zahlen */

#include <stdlib.h>
#include <stdio.h>

int main(void)
{
  unsigned int summe, a=5, b=7;

  /* Berechnung */
  summe=a+b;

  /* Ausgabe des Ergebnisses */
  printf("%d\n",summe)
  system("pause");
}
